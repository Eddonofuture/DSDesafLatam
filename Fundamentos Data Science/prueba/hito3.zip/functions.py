def printUniques(df, columnas):
    '''
    Funcion obtiene el listado de datos unicos del DataFrame
    Input (DataFrame , Array[])
    Output none
    '''
    for col in columnas:
        print(col , df[col].unique())

def replaceAll(df,listado, strObjetivo):
    import pandas as pd
    df = df.replace(listado,strObjetivo)
    return df

def concise_summary(mod,print_fit=True):
    '''
    Funcion permite entregar el sumario de una regresion
    Input (Regresion , Boolean)
    Output print
    '''
    import pandas as pd
    fit = pd.DataFrame({'Statistics': mod.summary2().tables[0][0][2:],
                       'Value': mod.summary2().tables[0][3][2:]})
    estimates = pd.DataFrame(mod.summary2().tables[1].loc[:,'Coef.':'Std.Err.'])
    if print_fit is True:
        print("\nGoodnes of Fit statistics\n", fit)
    print("\nPoint Estimates\n\n", estimates)
    
def logitCalculate(columns, df):
    '''
    Funcion que permite calculo de parametros de statsmodel con su logit incluyendo su interceptor
    Input: (List, DataFrame)
    Output: (int)
    '''
    import statsmodels.api as sm
    import statsmodels.formula.api as smf
    estimate_y = 0
    for i in columns:
        estimate_y += df.params[i]
    return invlogit(estimate_y)

def invlogit(x):
    '''
    Funcion apoyo, permite calculo logaritmico
    input: int
    output: int
    '''
    import numpy as np
    return 1/(1+ np.exp(-x))