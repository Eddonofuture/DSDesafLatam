def printUniques(df, columnas):
    '''
    Funcion obtiene el listado de datos unicos del DataFrame
    Input (DataFrame , Array[])
    Output none
    '''
    for col in columnas:
        print(col , df[col].unique())

def replaceAll(df,listado, strObjetivo):
    import pandas as pd
    df = df.replace(listado,strObjetivo)
    return df

