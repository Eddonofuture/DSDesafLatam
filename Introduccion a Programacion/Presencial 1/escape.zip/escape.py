import sys
import math

data = (math.sqrt((2*float(sys.argv[1])*float(sys.argv[2])*1000)))
print (str(round(data,3))) 