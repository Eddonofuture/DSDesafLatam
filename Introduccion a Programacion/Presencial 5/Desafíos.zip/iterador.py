#Se transforma de while a for, desde 1 hasta 50
for i in range (0 , 50):
    print("Iteracion {}".format(i + 1))

