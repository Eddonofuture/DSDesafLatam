import numpy as np

def promedio(velocidad):
    return ( np.mean(velocidad))
    