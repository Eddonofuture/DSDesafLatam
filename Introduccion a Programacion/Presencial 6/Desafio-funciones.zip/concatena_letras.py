def gen(letras):
    abecedario = 'abcdefghijklmnopqrstuvwxyz'
    return abecedario[0:letras]    
